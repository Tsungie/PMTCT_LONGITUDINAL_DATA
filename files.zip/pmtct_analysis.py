"""
PMTCT Mother-Baby Pair Longitudinal Analysis
=============================================
This script analyzes Prevention of Mother-to-Child Transmission (PMTCT) data
across two cohorts: children with traceable mothers and those without.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Set style for visualizations
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

# ============================================================================
# DATA LOADING AND PREPARATION
# ============================================================================

def load_and_prepare_data():
    """Load both datasets and prepare them for analysis"""
    
    # Load datasets
    no_mother = pd.read_csv('DATA_SET_WITH_NO_TRACEABLE_MOTHER.csv')
    with_mother = pd.read_csv('DATA_SET_WITH_TRACE_OF_THE_MOTHER.csv')
    
    # Add dataset identifier
    no_mother['cohort'] = 'No Traceable Mother'
    with_mother['cohort'] = 'With Mother Data'
    
    print(f"Dataset with no traceable mother: {len(no_mother)} records")
    print(f"Dataset with mother data: {len(with_mother)} records")
    print(f"Total records: {len(no_mother) + len(with_mother)}")
    
    return no_mother, with_mother

# ============================================================================
# COHORT 1 ANALYSIS: CHILDREN WITHOUT TRACEABLE MOTHERS
# ============================================================================

def analyze_orphan_cohort(df):
    """Analyze children without traceable mothers"""
    
    print("\n" + "="*70)
    print("COHORT 1: CHILDREN WITHOUT TRACEABLE MOTHERS")
    print("="*70)
    
    # Convert dates
    date_cols = ['infant_date_of_birth', 'infant_hiv_test_date', 
                 'infant_date_of_art_initiation', 'infant_date_of_art_enrolment']
    
    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce', dayfirst=True)
    
    # Basic demographics
    print("\n1. DEMOGRAPHIC PROFILE")
    print("-" * 50)
    print(f"Total children: {len(df)}")
    print(f"\nGender Distribution:")
    print(df['infant_sex'].value_counts())
    print(f"\nGender Percentages:")
    print(df['infant_sex'].value_counts(normalize=True) * 100)
    
    # Age at testing
    print("\n2. AGE AT HIV TESTING")
    print("-" * 50)
    df['child_age_at_test_clean'] = pd.to_numeric(df['child_age_at_test'], errors='coerce')
    
    # Filter out anomalies (negative ages)
    valid_ages = df[df['child_age_at_test_clean'] >= 0]['child_age_at_test_clean']
    
    print(f"Mean age at testing: {valid_ages.mean():.1f} months")
    print(f"Median age at testing: {valid_ages.median():.1f} months")
    print(f"Min age at testing: {valid_ages.min():.1f} months")
    print(f"Max age at testing: {valid_ages.max():.1f} months")
    
    # Age categories
    df['age_category'] = pd.cut(df['child_age_at_test_clean'], 
                                 bins=[-1, 2, 6, 12, 24, 60, 200],
                                 labels=['0-2 months', '3-6 months', '7-12 months', 
                                        '13-24 months', '2-5 years', '>5 years'])
    print(f"\nAge Categories at Testing:")
    print(df['age_category'].value_counts().sort_index())
    
    # HIV test results
    print("\n3. HIV TEST RESULTS")
    print("-" * 50)
    df['test_result_clean'] = df['infant_hiv_test_result'].str.upper()
    print(df['test_result_clean'].value_counts())
    
    # ART status
    print("\n4. ART TREATMENT STATUS")
    print("-" * 50)
    print("ART Status:")
    print(df['infant_current_art_status'].value_counts())
    
    print("\nFollow-up Status:")
    print(df['infant_follow_up_status'].value_counts())
    
    # Treatment initiation timing
    df['days_to_art_initiation'] = (df['infant_date_of_art_initiation'] - 
                                     df['infant_hiv_test_date']).dt.days
    
    valid_days = df['days_to_art_initiation'].dropna()
    if len(valid_days) > 0:
        print(f"\nDays from diagnosis to ART initiation:")
        print(f"Mean: {valid_days.mean():.1f} days")
        print(f"Median: {valid_days.median():.1f} days")
    
    # Facility distribution
    print("\n5. TOP 10 FACILITIES")
    print("-" * 50)
    print(df['facility'].value_counts().head(10))
    
    # Temporal trends
    df['test_year'] = df['infant_hiv_test_date'].dt.year
    print("\n6. TESTING TRENDS BY YEAR")
    print("-" * 50)
    print(df['test_year'].value_counts().sort_index())
    
    return df

# ============================================================================
# COHORT 2 ANALYSIS: MOTHER-BABY PAIRS WITH COMPLETE DATA
# ============================================================================

def analyze_mother_baby_pairs(df):
    """Analyze mother-baby pairs with complete linkage"""
    
    print("\n" + "="*70)
    print("COHORT 2: MOTHER-BABY PAIRS WITH COMPLETE DATA")
    print("="*70)
    
    # Convert dates
    date_cols = ['mother_date_of_birth', 'date_of_anc_booking', 'mother_date_of_hiv_test',
                 'date_mother_tested_positive', 'mother_date_of_art_initiation',
                 'infant_date_of_birth', 'date_of_delivery', 'mother_date_of_viral_load']
    
    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce', dayfirst=True)
    
    # MOTHER CHARACTERISTICS
    print("\n1. MATERNAL CHARACTERISTICS")
    print("-" * 50)
    print(f"Total mother-baby pairs: {len(df)}")
    
    print(f"\nMother's age at booking:")
    print(f"Mean: {df['mother_age_at_booking'].mean():.1f} years")
    print(f"Median: {df['mother_age_at_booking'].median():.1f} years")
    print(f"Range: {df['mother_age_at_booking'].min():.0f} - {df['mother_age_at_booking'].max():.0f} years")
    
    # Age categories
    df['mother_age_group'] = pd.cut(df['mother_age_at_booking'],
                                     bins=[0, 19, 24, 29, 34, 100],
                                     labels=['<20', '20-24', '25-29', '30-34', '35+'])
    print(f"\nMaternal Age Distribution:")
    print(df['mother_age_group'].value_counts().sort_index())
    
    # First time booking
    print(f"\nFirst-time ANC booking:")
    print(df['first_time_booking'].value_counts())
    
    # HIV status at booking
    print("\n2. HIV STATUS AT ANC BOOKING")
    print("-" * 50)
    print(df['mother_hiv_status_at_booking'].value_counts())
    
    # Test results
    print(f"\nHIV Test Results:")
    df['mother_test_result_clean'] = df['mother_hiv_test_result'].str.upper()
    print(df['mother_test_result_clean'].value_counts())
    
    # ART INITIATION TIMING
    print("\n3. TIMING OF ART INITIATION")
    print("-" * 50)
    
    print("Started ART before current pregnancy:")
    print(df['mother_started_art_before_current_pregnancy'].value_counts())
    
    print("\nStarted ART during pregnancy (>4 weeks before delivery):")
    print(df['mother_started_art_during_pregnancy_gt4weeks_before_delivery'].value_counts())
    
    print("\nStarted ART during pregnancy (<4 weeks before delivery):")
    print(df['mother_started_art_during_pregnancy_lss4weeks_before_delivery'].value_counts())
    
    # Calculate time from diagnosis to ART
    df['days_diagnosis_to_art'] = (df['mother_date_of_art_initiation'] - 
                                    df['date_mother_tested_positive']).dt.days
    
    valid_days = df['days_diagnosis_to_art'].dropna()
    if len(valid_days) > 0:
        print(f"\nDays from HIV diagnosis to ART initiation:")
        print(f"Mean: {valid_days.mean():.1f} days")
        print(f"Median: {valid_days.median():.1f} days")
        same_day = (valid_days == 0).sum()
        print(f"Same-day initiation: {same_day} ({same_day/len(valid_days)*100:.1f}%)")
    
    # VIRAL LOAD SUPPRESSION
    print("\n4. VIRAL LOAD OUTCOMES")
    print("-" * 50)
    
    # Parse viral load results
    df['vl_numeric'] = pd.to_numeric(df['mother_viral_load_result'], errors='coerce')
    df['vl_suppressed'] = df['mother_viral_load_result'].apply(
        lambda x: 'Suppressed' if pd.notna(x) and (str(x).upper() in ['TND', '<30', '<20', '<50'] or 
                  (isinstance(x, (int, float)) and x < 1000)) else 
                  'Not Suppressed' if pd.notna(x) else 'Unknown'
    )
    
    print("Viral Load Status:")
    print(df['vl_suppressed'].value_counts())
    
    vl_tested = df[df['vl_suppressed'] != 'Unknown']
    if len(vl_tested) > 0:
        suppression_rate = (vl_tested['vl_suppressed'] == 'Suppressed').sum() / len(vl_tested) * 100
        print(f"\nViral suppression rate: {suppression_rate:.1f}%")
    
    # ART REGIMEN
    print("\n5. ART REGIMEN")
    print("-" * 50)
    print(df['mother_regimen'].value_counts())
    
    # INFANT OUTCOMES
    print("\n6. INFANT OUTCOMES")
    print("-" * 50)
    
    # Calculate gestational age at delivery
    try:
        df['date_of_last_known_mensural_period'] = pd.to_datetime(df['date_of_last_known_mensural_period'], 
                                                                   errors='coerce', dayfirst=True)
        df['gestational_weeks'] = ((df['date_of_delivery'] - 
                                    df['date_of_last_known_mensural_period']).dt.days / 7)
    except:
        df['gestational_weeks'] = np.nan
    
    valid_ga = df[(df['gestational_weeks'] > 20) & (df['gestational_weeks'] < 45)]
    if len(valid_ga) > 0:
        print(f"Gestational age at delivery:")
        print(f"Mean: {valid_ga['gestational_weeks'].mean():.1f} weeks")
        print(f"Median: {valid_ga['gestational_weeks'].median():.1f} weeks")
    
    # Infant HIV testing
    infant_tested = df[df['infant_hiv_test_result'].notna()]
    print(f"\nInfants with HIV test results: {len(infant_tested)} ({len(infant_tested)/len(df)*100:.1f}%)")
    
    if len(infant_tested) > 0:
        print("\nInfant HIV Test Results:")
        print(infant_tested['infant_hiv_test_result'].value_counts())
        
        # Calculate MTCT rate
        positive_tests = infant_tested['infant_hiv_test_result'].str.upper().isin(['POSITIVE'])
        mtct_rate = positive_tests.sum() / len(infant_tested) * 100
        print(f"\nMother-to-Child Transmission Rate: {mtct_rate:.1f}%")
    
    # FACILITY ANALYSIS
    print("\n7. TOP 10 FACILITIES")
    print("-" * 50)
    print(df['facility'].value_counts().head(10))
    
    return df

# ============================================================================
# COMPARATIVE ANALYSIS
# ============================================================================

def comparative_analysis(no_mother_df, with_mother_df):
    """Compare outcomes between both cohorts"""
    
    print("\n" + "="*70)
    print("COMPARATIVE ANALYSIS")
    print("="*70)
    
    print("\n1. COHORT SIZES")
    print("-" * 50)
    print(f"Children without traceable mothers: {len(no_mother_df)}")
    print(f"Mother-baby pairs with complete data: {len(with_mother_df)}")
    
    print("\n2. HIV-POSITIVE CHILDREN")
    print("-" * 50)
    
    # Orphan cohort
    orphan_positive = no_mother_df['child_hiv_status'].str.upper().isin(['POSITIVE']).sum()
    print(f"Orphan cohort HIV+: {orphan_positive} ({orphan_positive/len(no_mother_df)*100:.1f}%)")
    
    # Mother-baby pairs
    if 'infant_hiv_test_result' in with_mother_df.columns:
        tested = with_mother_df[with_mother_df['infant_hiv_test_result'].notna()]
        mb_positive = tested['infant_hiv_test_result'].str.upper().isin(['POSITIVE']).sum()
        if len(tested) > 0:
            print(f"Mother-baby pairs HIV+: {mb_positive}/{len(tested)} ({mb_positive/len(tested)*100:.1f}%)")
    
    print("\n3. ART COVERAGE")
    print("-" * 50)
    
    # Orphan cohort ART coverage
    orphan_on_art = no_mother_df['infant_follow_up_status'].str.contains('Active', na=False).sum()
    print(f"Orphan cohort on ART: {orphan_on_art} ({orphan_on_art/orphan_positive*100:.1f}% of HIV+ children)")
    
    # Mother cohort ART coverage (mothers)
    mothers_on_art = with_mother_df['mother_date_of_art_initiation'].notna().sum()
    print(f"Mothers initiated on ART: {mothers_on_art} ({mothers_on_art/len(with_mother_df)*100:.1f}%)")

# ============================================================================
# VISUALIZATION FUNCTIONS
# ============================================================================

def create_visualizations(no_mother_df, with_mother_df):
    """Create comprehensive visualizations"""
    
    print("\n" + "="*70)
    print("CREATING VISUALIZATIONS")
    print("="*70)
    
    # Set up the plotting area
    fig = plt.figure(figsize=(20, 24))
    
    # 1. Cohort sizes
    ax1 = plt.subplot(4, 3, 1)
    cohorts = ['Without Mother\nData', 'With Mother\nData']
    sizes = [len(no_mother_df), len(with_mother_df)]
    colors = ['#e74c3c', '#3498db']
    ax1.bar(cohorts, sizes, color=colors, alpha=0.7, edgecolor='black')
    ax1.set_ylabel('Number of Records', fontsize=10)
    ax1.set_title('Dataset Sizes by Cohort', fontsize=12, fontweight='bold')
    for i, v in enumerate(sizes):
        ax1.text(i, v + 50, str(v), ha='center', va='bottom', fontweight='bold')
    
    # 2. Gender distribution - Orphan cohort
    ax2 = plt.subplot(4, 3, 2)
    gender_counts = no_mother_df['infant_sex'].value_counts()
    ax2.pie(gender_counts, labels=gender_counts.index, autopct='%1.1f%%', 
            colors=['#e74c3c', '#3498db'], startangle=90)
    ax2.set_title('Gender Distribution\n(Children Without Mother Data)', 
                  fontsize=12, fontweight='bold')
    
    # 3. Age at testing - Orphan cohort
    ax3 = plt.subplot(4, 3, 3)
    age_cats = no_mother_df['age_category'].value_counts().sort_index()
    ax3.barh(range(len(age_cats)), age_cats.values, color='#e74c3c', alpha=0.7)
    ax3.set_yticks(range(len(age_cats)))
    ax3.set_yticklabels(age_cats.index)
    ax3.set_xlabel('Number of Children', fontsize=10)
    ax3.set_title('Age at HIV Testing\n(Children Without Mother Data)', 
                  fontsize=12, fontweight='bold')
    
    # 4. Testing trends over time - Orphan cohort
    ax4 = plt.subplot(4, 3, 4)
    yearly_tests = no_mother_df['test_year'].value_counts().sort_index()
    ax4.plot(yearly_tests.index, yearly_tests.values, marker='o', 
             color='#e74c3c', linewidth=2, markersize=8)
    ax4.set_xlabel('Year', fontsize=10)
    ax4.set_ylabel('Number of Tests', fontsize=10)
    ax4.set_title('HIV Testing Trends Over Time\n(Children Without Mother Data)', 
                  fontsize=12, fontweight='bold')
    ax4.grid(True, alpha=0.3)
    
    # 5. ART status - Orphan cohort
    ax5 = plt.subplot(4, 3, 5)
    art_status = no_mother_df['infant_follow_up_status'].value_counts()
    ax5.bar(range(len(art_status)), art_status.values, color='#e74c3c', alpha=0.7)
    ax5.set_xticks(range(len(art_status)))
    ax5.set_xticklabels(art_status.index, rotation=45, ha='right')
    ax5.set_ylabel('Number of Children', fontsize=10)
    ax5.set_title('Treatment Follow-up Status\n(Children Without Mother Data)', 
                  fontsize=12, fontweight='bold')
    
    # 6. Top facilities - Orphan cohort
    ax6 = plt.subplot(4, 3, 6)
    top_facilities = no_mother_df['facility'].value_counts().head(10)
    ax6.barh(range(len(top_facilities)), top_facilities.values, color='#e74c3c', alpha=0.7)
    ax6.set_yticks(range(len(top_facilities)))
    ax6.set_yticklabels(top_facilities.index, fontsize=8)
    ax6.set_xlabel('Number of Cases', fontsize=10)
    ax6.set_title('Top 10 Facilities\n(Children Without Mother Data)', 
                  fontsize=12, fontweight='bold')
    
    # 7. Maternal age distribution
    ax7 = plt.subplot(4, 3, 7)
    age_groups = with_mother_df['mother_age_group'].value_counts().sort_index()
    ax7.bar(range(len(age_groups)), age_groups.values, color='#3498db', alpha=0.7)
    ax7.set_xticks(range(len(age_groups)))
    ax7.set_xticklabels(age_groups.index)
    ax7.set_ylabel('Number of Mothers', fontsize=10)
    ax7.set_title('Maternal Age Distribution', fontsize=12, fontweight='bold')
    
    # 8. ART initiation timing
    ax8 = plt.subplot(4, 3, 8)
    art_timing = pd.DataFrame({
        'Before Pregnancy': [with_mother_df['mother_started_art_before_current_pregnancy'].eq('Yes').sum()],
        'During Pregnancy\n(>4 weeks)': [with_mother_df['mother_started_art_during_pregnancy_gt4weeks_before_delivery'].eq('Yes').sum()],
        'During Pregnancy\n(<4 weeks)': [with_mother_df['mother_started_art_during_pregnancy_lss4weeks_before_delivery'].eq('Yes').sum()]
    })
    art_timing.T.plot(kind='bar', ax=ax8, color='#3498db', alpha=0.7, legend=False)
    ax8.set_ylabel('Number of Mothers', fontsize=10)
    ax8.set_xticklabels(art_timing.columns, rotation=45, ha='right')
    ax8.set_title('Timing of ART Initiation', fontsize=12, fontweight='bold')
    
    # 9. Viral load suppression
    ax9 = plt.subplot(4, 3, 9)
    vl_status = with_mother_df['vl_suppressed'].value_counts()
    colors_vl = {'Suppressed': '#27ae60', 'Not Suppressed': '#e74c3c', 'Unknown': '#95a5a6'}
    vl_colors = [colors_vl.get(x, '#95a5a6') for x in vl_status.index]
    ax9.pie(vl_status, labels=vl_status.index, autopct='%1.1f%%', 
            colors=vl_colors, startangle=90)
    ax9.set_title('Maternal Viral Load Status', fontsize=12, fontweight='bold')
    
    # 10. Infant testing rates
    ax10 = plt.subplot(4, 3, 10)
    tested = with_mother_df['infant_hiv_test_result'].notna().sum()
    not_tested = len(with_mother_df) - tested
    ax10.bar(['Tested', 'Not Tested'], [tested, not_tested], 
             color=['#27ae60', '#e74c3c'], alpha=0.7)
    ax10.set_ylabel('Number of Infants', fontsize=10)
    ax10.set_title('Infant HIV Testing Coverage', fontsize=12, fontweight='bold')
    for i, v in enumerate([tested, not_tested]):
        ax10.text(i, v + 20, f'{v}\n({v/len(with_mother_df)*100:.1f}%)', 
                 ha='center', va='bottom', fontweight='bold')
    
    # 11. MTCT outcomes
    ax11 = plt.subplot(4, 3, 11)
    infant_tested = with_mother_df[with_mother_df['infant_hiv_test_result'].notna()]
    if len(infant_tested) > 0:
        results = infant_tested['infant_hiv_test_result'].str.upper().value_counts()
        ax11.pie(results, labels=results.index, autopct='%1.1f%%', 
                colors=['#27ae60', '#e74c3c'], startangle=90)
        ax11.set_title('Infant HIV Test Results\n(Among Tested)', 
                      fontsize=12, fontweight='bold')
    
    # 12. Top facilities - Mother-baby pairs
    ax12 = plt.subplot(4, 3, 12)
    top_facilities_mb = with_mother_df['facility'].value_counts().head(10)
    ax12.barh(range(len(top_facilities_mb)), top_facilities_mb.values, 
             color='#3498db', alpha=0.7)
    ax12.set_yticks(range(len(top_facilities_mb)))
    ax12.set_yticklabels(top_facilities_mb.index, fontsize=8)
    ax12.set_xlabel('Number of Cases', fontsize=10)
    ax12.set_title('Top 10 Facilities\n(Mother-Baby Pairs)', 
                  fontsize=12, fontweight='bold')
    
    plt.tight_layout()
    output_path = '/mnt/user-data/outputs/pmtct_comprehensive_analysis.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"✓ Main dashboard saved as '{output_path}'")
    
    # Create cascade analysis visualization
    create_cascade_visualization(no_mother_df, with_mother_df)

def create_cascade_visualization(no_mother_df, with_mother_df):
    """Create PMTCT cascade visualization"""
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
    
    # Cascade for orphan cohort
    total_orphans = len(no_mother_df)
    tested_positive = no_mother_df['child_hiv_status'].str.upper().isin(['POSITIVE']).sum()
    on_art = no_mother_df['infant_follow_up_status'].str.contains('Active', na=False).sum()
    
    stages_orphan = ['HIV+ Identified', 'Initiated on ART', 'Active on Treatment']
    values_orphan = [tested_positive, 
                     no_mother_df['infant_date_of_art_initiation'].notna().sum(),
                     on_art]
    
    colors_cascade = ['#e74c3c', '#e67e22', '#27ae60']
    bars1 = ax1.barh(stages_orphan, values_orphan, color=colors_cascade, alpha=0.7)
    ax1.set_xlabel('Number of Children', fontsize=12)
    ax1.set_title('Treatment Cascade\n(Children Without Mother Data)', 
                 fontsize=14, fontweight='bold')
    
    for i, (bar, val) in enumerate(zip(bars1, values_orphan)):
        percentage = (val / tested_positive * 100) if tested_positive > 0 else 0
        ax1.text(val + 5, bar.get_y() + bar.get_height()/2, 
                f'{val} ({percentage:.1f}%)', 
                va='center', fontweight='bold')
    
    # Cascade for mother-baby pairs
    total_mothers = len(with_mother_df)
    mothers_hiv_positive = with_mother_df['mother_hiv_test_result'].str.upper().isin(['POSITIVE']).sum()
    mothers_on_art = with_mother_df['mother_date_of_art_initiation'].notna().sum()
    mothers_suppressed = (with_mother_df['vl_suppressed'] == 'Suppressed').sum()
    
    stages_mother = ['HIV+ Mothers', 'Initiated on ART', 
                    'Virally Suppressed', 'Infants Tested']
    
    infant_tested = with_mother_df['infant_hiv_test_result'].notna().sum()
    
    values_mother = [mothers_hiv_positive, mothers_on_art, 
                    mothers_suppressed, infant_tested]
    
    bars2 = ax2.barh(stages_mother, values_mother, color=colors_cascade + ['#3498db'], alpha=0.7)
    ax2.set_xlabel('Number', fontsize=12)
    ax2.set_title('PMTCT Cascade\n(Mother-Baby Pairs)', 
                 fontsize=14, fontweight='bold')
    
    for i, (bar, val) in enumerate(zip(bars2, values_mother)):
        percentage = (val / mothers_hiv_positive * 100) if mothers_hiv_positive > 0 else 0
        ax2.text(val + 20, bar.get_y() + bar.get_height()/2, 
                f'{val} ({percentage:.1f}%)', 
                va='center', fontweight='bold')
    
    plt.tight_layout()
    output_path = '/mnt/user-data/outputs/pmtct_cascade_analysis.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    print(f"✓ Cascade analysis saved as '{output_path}'")

# ============================================================================
# KEY FINDINGS SUMMARY
# ============================================================================

def generate_key_findings(no_mother_df, with_mother_df):
    """Generate executive summary of key findings"""
    
    print("\n" + "="*70)
    print("KEY FINDINGS & RECOMMENDATIONS")
    print("="*70)
    
    print("\n📊 COHORT 1: CHILDREN WITHOUT TRACEABLE MOTHERS")
    print("-" * 50)
    
    orphan_positive = no_mother_df['child_hiv_status'].str.upper().isin(['POSITIVE']).sum()
    orphan_on_art = no_mother_df['infant_follow_up_status'].str.contains('Active', na=False).sum()
    
    print(f"• Total HIV+ children identified: {orphan_positive}")
    print(f"• Children actively on treatment: {orphan_on_art} ({orphan_on_art/orphan_positive*100:.1f}% coverage)")
    
    valid_ages = no_mother_df[no_mother_df['child_age_at_test_clean'] >= 0]['child_age_at_test_clean']
    late_testers = (valid_ages > 12).sum()
    print(f"• Children tested after 12 months: {late_testers} ({late_testers/len(valid_ages)*100:.1f}%)")
    
    print("\n📊 COHORT 2: MOTHER-BABY PAIRS")
    print("-" * 50)
    
    mothers_hiv_positive = with_mother_df['mother_hiv_test_result'].str.upper().isin(['POSITIVE']).sum()
    mothers_on_art = with_mother_df['mother_date_of_art_initiation'].notna().sum()
    
    print(f"• HIV+ mothers identified: {mothers_hiv_positive}")
    print(f"• Mothers initiated on ART: {mothers_on_art} ({mothers_on_art/mothers_hiv_positive*100:.1f}%)")
    
    # Same day initiation
    same_day = (with_mother_df['days_diagnosis_to_art'] == 0).sum()
    total_with_timing = with_mother_df['days_diagnosis_to_art'].notna().sum()
    if total_with_timing > 0:
        print(f"• Same-day ART initiation: {same_day} ({same_day/total_with_timing*100:.1f}%)")
    
    # Viral suppression
    vl_tested = with_mother_df[with_mother_df['vl_suppressed'] != 'Unknown']
    if len(vl_tested) > 0:
        suppressed = (vl_tested['vl_suppressed'] == 'Suppressed').sum()
        print(f"• Viral suppression rate: {suppressed}/{len(vl_tested)} ({suppressed/len(vl_tested)*100:.1f}%)")
    
    # MTCT rate
    infant_tested = with_mother_df[with_mother_df['infant_hiv_test_result'].notna()]
    if len(infant_tested) > 0:
        infant_positive = infant_tested['infant_hiv_test_result'].str.upper().isin(['POSITIVE']).sum()
        mtct_rate = infant_positive / len(infant_tested) * 100
        print(f"• Mother-to-child transmission rate: {infant_positive}/{len(infant_tested)} ({mtct_rate:.1f}%)")
        print(f"• Infant testing coverage: {len(infant_tested)}/{len(with_mother_df)} ({len(infant_tested)/len(with_mother_df)*100:.1f}%)")
    
    print("\n⚠️  CRITICAL GAPS IDENTIFIED")
    print("-" * 50)
    print("1. High proportion of children without traceable mothers")
    print("2. Late HIV testing in orphan cohort (many >12 months)")
    print("3. Incomplete infant testing in mother-baby pairs")
    print("4. Treatment retention challenges")
    
    print("\n💡 RECOMMENDATIONS")
    print("-" * 50)
    print("1. Strengthen mother-baby linkage systems")
    print("2. Implement early infant diagnosis protocols")
    print("3. Enhance contact tracing for lost-to-follow-up cases")
    print("4. Scale up same-day ART initiation for mothers")
    print("5. Improve viral load monitoring and suppression rates")

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """Main execution function"""
    
    print("="*70)
    print("PMTCT LONGITUDINAL DATA ANALYSIS")
    print("Prevention of Mother-to-Child Transmission Programme")
    print("="*70)
    
    # Load data
    no_mother_df, with_mother_df = load_and_prepare_data()
    
    # Analyze both cohorts
    no_mother_df = analyze_orphan_cohort(no_mother_df)
    with_mother_df = analyze_mother_baby_pairs(with_mother_df)
    
    # Comparative analysis
    comparative_analysis(no_mother_df, with_mother_df)
    
    # Create visualizations
    create_visualizations(no_mother_df, with_mother_df)
    
    # Generate key findings
    generate_key_findings(no_mother_df, with_mother_df)
    
    print("\n" + "="*70)
    print("ANALYSIS COMPLETE!")
    print("="*70)
    print("\n📁 Output files generated:")
    print("  • pmtct_comprehensive_analysis.png")
    print("  • pmtct_cascade_analysis.png")

if __name__ == "__main__":
    main()
