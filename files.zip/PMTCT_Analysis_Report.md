# PMTCT Longitudinal Data Analysis: A Story of Two Cohorts

## Executive Summary

This analysis examines **3,092 records** from Zimbabwe's Prevention of Mother-to-Child Transmission (PMTCT) programme, revealing two distinct narratives: **1,211 HIV-positive children without traceable mothers** and **1,881 mother-baby pairs with complete linkage data**. The findings expose critical gaps in the care cascade while highlighting successes in same-day ART initiation and viral suppression.

---

## The Two Cohorts: A Tale of Disconnection and Connection

### Cohort 1: The Orphaned Data (1,211 children)

These are children identified as HIV-positive but with **no traceable connection to their mothers**. This cohort tells a troubling story of system fragmentation:

**Who are these children?**
- **Gender distribution**: 55% female, 45% male
- **Mean age at HIV testing**: 5.4 months (median: 4 months)
- **100% HIV-positive** (by definition, as they're in this dataset due to confirmed infection)

**The Testing Timeline:**
- **43% tested at 0-2 months** – These are the success stories of early infant diagnosis
- **28% tested at 7-12 months** – Delayed but within guideline recommendations
- **13% tested after 12 months** – Concerning late diagnosis
- **13% tested at 13-24 months** – Critical delays that increase morbidity risk

**Treatment Cascade Breakdown:**
The cascade shows significant attrition:
1. **1,211 HIV+ children identified** (100%)
2. **671 initiated on ART** (55.4%)
3. **591 actively on treatment** (48.8%)

This means **over half of identified HIV+ children are not actively on treatment** – a critical gap.

**What happened to the "lost" children?**
- 65 transferred out (possibly still in care elsewhere)
- 12 died
- 3 lost to follow-up (documented)
- 3 opted out
- Unknown status for hundreds more

**Temporal Trends:**
Testing peaked in 2021-2022 (161 cases in 2022), suggesting:
- Improved case-finding during COVID-19 response scale-up
- Better data systems capturing previously "invisible" children
- Potential backlog testing from pandemic disruptions

---

### Cohort 2: Connected Care (1,881 mother-baby pairs)

This cohort represents the **PMTCT programme as designed** – with full mother-baby linkage, ANC booking, and follow-up data.

**Maternal Profile:**
- **Mean age**: 27.8 years (range: 14-51)
- **Age distribution**:
  - 10% adolescents (<20 years) – a high-risk group
  - 52% aged 20-29 years
  - 38% aged 30+ years
- **63% first-time ANC bookers** – suggesting good early engagement

**The Prevention Cascade:**

**Stage 1: HIV Testing at ANC**
- **100% tested HIV-positive** (this is the study population)
- All mothers received their diagnosis

**Stage 2: ART Initiation Timing** (Critical for viral suppression)
The WHO recommends starting ART as early as possible. Our data shows:

- **29% (552) started ART before pregnancy** – Ideal scenario
- **15% (274) started during pregnancy (>4 weeks before delivery)** – Good
- **1% (19) started <4 weeks before delivery** – Suboptimal
- **56% unknown timing** – Data gap

**The Same-Day Initiation Success:**
Among those with timing data:
- **67.6% started ART on the same day as diagnosis** – Outstanding achievement
- Median 0 days from diagnosis to treatment
- Mean 94 days (skewed by historical delays)

**Stage 3: Viral Suppression**
Among 586 mothers with viral load results:
- **61.6% achieved viral suppression** (<1000 copies/mL or undetectable)
- **38.4% not suppressed** – concerning for MTCT risk
- **69% had no viral load result documented** – massive data/testing gap

**Stage 4: Infant Outcomes**

Here the story becomes troubling:

**Infant HIV Testing:**
- **Only 251 infants (13.3%) have documented HIV test results**
- **86.7% of infants have no documented test result**

This is the **most critical gap** in the entire cascade.

**Among the 251 tested infants:**
- **232 tested HIV-negative (92.4%)** – Excellent!
- **12 tested HIV-positive (4.8%)** – MTCT occurred
- **7 inconclusive/undefined results**

**The 4.8% MTCT rate** is actually **promising** (WHO target is <5% with ART), but this only represents tested infants – we don't know the status of the other 86.7%.

**Gestational Age:**
- Mean: 37.6 weeks
- Median: 38.6 weeks
- Most deliveries were term, reducing prematurity-related risks

---

## Critical Analysis: What the Numbers Mean

### Success Stories

**1. Same-Day ART Initiation**
The 67.6% same-day initiation rate is **world-class**. This reflects:
- Strong implementation of Test & Treat policies
- Good ANC staff training
- Availability of medications
- Reduced stigma and improved counseling

**2. Low MTCT Rate Among Tested**
The 4.8% transmission rate **among tested infants** meets WHO elimination targets (<5%).

**3. Viral Suppression**
The 61.6% suppression rate, while not ideal, shows that ARVs work when mothers adhere.

**4. Early Testing in Orphan Cohort**
43% of the "orphaned" children were tested by 2 months – showing that early infant diagnosis systems can work.

### Critical Gaps

**1. The "Missing Mothers" Problem**
- 1,211 children with no traceable maternal data
- Suggests breakdown in:
  - Mother-baby pair registration
  - Documentation systems
  - Possible maternal death/abandonment
  - Inter-facility transfer tracking

**2. The Infant Testing Crisis**
- **86.7% of infants unaccounted for in testing records**
- This is the **biggest failure** in the cascade
- Possible reasons:
  - Loss to follow-up after delivery
  - Testing done but not documented
  - Mothers deliver at one facility, seek care at another
  - Home deliveries
  - Maternal death

**3. Treatment Retention**
- Only 48.8% of HIV+ children actively on treatment
- High loss between identification and sustained care

**4. Viral Load Testing Gaps**
- 69% of mothers have no VL documentation
- Without VL monitoring, can't assess:
  - Treatment efficacy
  - Need for regimen change
  - Actual MTCT risk

---

## Geographic Patterns

**Top 10 Facilities (Orphan Cohort):**
1. St.Mary's Clinic – 124 cases
2. Mbare Polyclinic – 96 cases
3. Mutawatawa – 84 cases

**Top 10 Facilities (Mother-Baby Pairs):**
1. St Padre Pio – 237 pairs
2. St.Mary's Clinic – 139 pairs
3. Princess Margaret – 130 pairs

**Insights:**
- Large urban centers (Mbare, Harare facilities) have high volumes
- Some facilities appear in both lists (St.Mary's, Mutawatawa) – suggesting they serve both populations
- Rural facilities also prominent (Mutawatawa, Zimunya)

---

## Recommendations

### Immediate Priorities (0-6 months)

**1. Infant Testing Surge Initiative**
- **Target**: Test all 1,630 untested infants
- Community tracing teams for mothers who didn't return
- Mobile testing units at high-volume facilities
- SMS/phone reminder systems

**2. Mother-Baby Linkage Strengthening**
- Implement unique mother-baby pair identifiers
- Electronic linkage between ANC, labor/delivery, and pediatric registers
- Flag unlinked cases for immediate investigation

**3. Viral Load Testing Scale-Up**
- Target 95% coverage for all mothers in PMTCT
- Point-of-care VL machines at high-volume sites
- Results-to-action protocols for non-suppressed mothers

### Medium-Term Strategies (6-24 months)

**4. Treatment Retention Programme**
- Differentiated service delivery models
- Multi-month prescriptions
- Community adherence support groups
- Address stigma and disclosure issues

**5. Data Quality Improvement**
- Standardized data collection tools
- Regular data quality audits
- Interoperability between facility systems
- Real-time dashboard for cascade monitoring

**6. Address the "Orphan Cohort"**
- Investigate why 1,211 children lack maternal linkage
- Strengthen social services for maternal orphans
- Improve documentation at delivery

### Long-Term Vision (2-5 years)

**7. Elimination of MTCT**
- Achieve <2% MTCT rate
- 95-95-95 targets for mothers (95% diagnosed, 95% on ART, 95% suppressed)
- Universal infant testing at 6 weeks and 18 months

**8. Integration with Broader Health Systems**
- Integrate PMTCT with MCH services
- One-stop shops for maternal-child health
- Address social determinants (poverty, food security)

---

## Conclusion: Two Stories, One Goal

These data tell two parallel stories:

**Story 1**: Children navigating the health system **alone**, without the protective link to their mothers. Many found late, many lost to follow-up, but some successfully treated.

**Story 2**: Mother-baby pairs in a **functional PMTCT system** with impressive same-day ART initiation, but faltering at the crucial step of infant testing and final outcome verification.

The **ultimate goal remains the same**: ensure **no child is born with HIV, and every HIV-positive child receives life-saving treatment**.

The data show we have the tools (same-day ART works, suppression is achievable, MTCT can be prevented), but we need to:
1. **Close the testing gap** (86.7% of infants untested)
2. **Link mothers and babies** (1,211 disconnected children)
3. **Retain in treatment** (48.8% active on ART is insufficient)

**The next phase of this program must focus on the "last mile"** – ensuring that every pregnancy identified in ANC translates to a tested infant, and every HIV-positive child receives sustained care.

---

## Data Notes

- **Total records analyzed**: 3,092
- **Analysis period**: Historical data through 2025
- **Geographic scope**: Zimbabwe health facilities
- **Data quality issues**: Missing test dates, negative ages, unlinked records suggest need for data cleaning protocols

---

*Analysis generated: February 2026*
*Data sources: PMTCT Programme Monitoring System*
